package com.example.csci3130project;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import com.example.csci3130project.LoginActivity;

import org.junit.BeforeClass;
import org.junit.Test;

//public class LoginValidationTests {
//
//    static LoginActivity logFragment;
//
//    @BeforeClass
//    public static void setup() {
//        logFragment = new LoginActivity();
//    }
//
//    @Test
//    public void isEmailEmptyTest() {
//        assertTrue(logFragment.isEmailEmpty(""));
//        assertFalse(logFragment.isEmailEmpty("123"));
//    }
//
//    @Test
//    public void isPasswordEmptyTest() {
//        assertTrue(logFragment.isPasswordEmpty(""));
//        assertFalse(logFragment.isPasswordEmpty("5645123"));
//    }
//}
