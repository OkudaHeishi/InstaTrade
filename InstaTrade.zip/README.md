# CSCI 3130 Project

```
Initial repo for the CSCI3130 group project.
We will be working on the "Online Barter Trader" proposal;
```
# Authors
- **Benjamin Chui** (B00812875)
- **Vincent Ordinelli** (B00846647)
- **Majed Yousef** (B00800967)
- **Erin Schultz** (B00846114)
- **Abu Sabi Ubada** (B00812077)
- **Nour Ali** (B00841206)
- **Hesham Elokdah** (B00843961)
